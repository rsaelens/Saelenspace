package org.intracode.saelenspace

import android.content.Intent
import android.graphics.Bitmap
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.design.widget.BottomNavigationView
import android.support.v4.view.MenuItemCompat
import android.view.Menu
import android.support.v7.widget.SearchView
import android.support.v7.widget.Toolbar
import android.view.MenuItem
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity() {


     override fun onCreate(savedInstanceState: Bundle?) {
         super.onCreate(savedInstanceState)
         setContentView(R.layout.activity_main)
         setSupportActionBar(findViewById(R.id.appToolBar))









             val bottomNav = findViewById(R.id.btmNav) as BottomNavigationView

         bottomNav.setOnNavigationItemSelectedListener { item ->
             when (item.itemId) {
                 R.id.nav_home -> {
                     val home = Intent(this@MainActivity, MainActivity::class.java)
                     startActivity(home)
                 }
                 R.id.nav_spark -> {
                     val sparky = Intent(this@MainActivity, MainSparkyActivity::class.java)
                     startActivity(sparky)
                 }
                 R.id.nav_connect -> {
                     val connect = Intent(this@MainActivity, MainConnectActivity::class.java)
                     startActivity(connect)
                 }
             }
             false
         }
     }

}




















