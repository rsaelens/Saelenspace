
package org.intracode.saelenspace

import android.content.Intent
import android.provider.ContactsContract
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.connect_row.view.recycText
import kotlinx.android.synthetic.main.spark_row.view.*

class SparkyAdapter:RecyclerView.Adapter<CustomSparkHold>(){

    val photos = arrayOf("")
    val subjectName = arrayOf("Arts", "Science", "Gaming", "Philosophy")
    val subField = arrayOf("Art, Music", "Computing, Energy, Medicine","2D, 3D, AR, VR", "Ethics, Logic, Metaphysics")


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CustomSparkHold {
        //creating a view
        val layoutInflater = LayoutInflater.from(parent.context)
        val cellForRow = layoutInflater.inflate(R.layout.spark_row, parent, false)
        return CustomSparkHold(cellForRow)

    }

    override fun onBindViewHolder(holder: CustomSparkHold, position: Int) {

        val subName = subjectName.get(position)
        holder.view.recycText.text = subName

        val subFields = subField.get(position)
        holder.view.subFieldText.text = subFields

        val thumbNailImage = holder.view.recyc_spark_image


    }

    //number of items
    override fun getItemCount(): Int {
        return subjectName.size
    }




}

class CustomSparkHold(val view: View): RecyclerView.ViewHolder(view){

    companion object{
        val subTitle = "Subject Title"
    }

    init{
        view.setOnClickListener {

            val intent = Intent(view.context, SubjectActivity::class.java)
            view.context.startActivity(intent)
            intent.putExtra(subTitle, "SubjectTitle")
        }
    }
}


