package org.intracode.saelenspace

import android.media.Image


class Subject(val images: List<Image>, val imageUrl: String){



}