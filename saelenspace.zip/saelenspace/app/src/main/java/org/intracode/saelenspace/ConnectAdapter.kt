package org.intracode.saelenspace

import android.content.Context
import android.content.Intent
import android.media.Image
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import kotlinx.android.synthetic.main.connect_row.view.*

class ConnectAdapter:RecyclerView.Adapter<CustomConnectHold>(){


    val companyName = arrayOf("Adafruit", "NASA", "OpenBCI", "SpaceX", "SparkFun", "Tesla")


     override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CustomConnectHold {
         //creating a view
        val layoutInflater = LayoutInflater.from(parent.context)
         val cellForRow = layoutInflater.inflate(R.layout.connect_row, parent, false)
         return CustomConnectHold(cellForRow)

     }

     override fun onBindViewHolder(holder: CustomConnectHold, position: Int) {

         val compName = companyName.get(position)
         holder.view.recycText.text = compName

     }

     //number of items
    override fun getItemCount(): Int {
        return companyName.size
    }




}

class CustomConnectHold(val view: View): RecyclerView.ViewHolder(view){

        }


