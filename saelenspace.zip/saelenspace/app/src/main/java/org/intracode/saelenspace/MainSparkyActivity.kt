package org.intracode.saelenspace

import android.content.Intent
import android.media.Image
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.support.design.widget.BottomNavigationView
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView

class MainSparkyActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_sparky)
        setSupportActionBar(findViewById(R.id.appToolBar))



        val RecyclerView = findViewById<RecyclerView>(R.id.sparkView)
        RecyclerView.layoutManager = LinearLayoutManager(this)
        RecyclerView.adapter = SparkyAdapter()
        










        val bottomNav = findViewById(R.id.btmNav) as BottomNavigationView

        bottomNav.setOnNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {
                    val home = Intent(this@MainSparkyActivity, MainActivity::class.java)
                    startActivity(home)
                }
                R.id.nav_spark -> {
                    val sparky = Intent(this@MainSparkyActivity, MainSparkyActivity::class.java)
                    startActivity(sparky)
                }
                R.id.nav_connect -> {
                    val connect = Intent(this@MainSparkyActivity, MainConnectActivity::class.java)
                    startActivity(connect)
                }
            }
            false
        }




    }




}