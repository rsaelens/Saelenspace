package org.intracode.saelenspace

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.design.widget.BottomNavigationView
import android.support.v4.content.ContextCompat
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.View
import android.view.ViewGroup
import android.widget.*
import kotlinx.android.synthetic.main.activity_main_connect.*
import java.net.ConnectException
import org.intracode.saelenspace.ConnectAdapter as ConnectAdapter

class MainConnectActivity : AppCompatActivity(){




    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_connect)
        setSupportActionBar(findViewById(R.id.appToolBar))

        connectScrollText.setSingleLine()
        connectScrollText.isSelected = true
        connectScrollText.text="CLICK ON THE COMPANY OF INTEREST TO LEARN MORE!"

        val RecyclerView = findViewById<RecyclerView>(R.id.connectRecyc)
        RecyclerView.layoutManager = LinearLayoutManager(this)
        RecyclerView.adapter = ConnectAdapter()














    val bottomNav = findViewById(R.id.btmNav) as BottomNavigationView

        bottomNav.setOnNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {
                    val home = Intent(this@MainConnectActivity, MainActivity::class.java)
                    startActivity(home)
                }
                R.id.nav_spark -> {
                    val sparky = Intent(this@MainConnectActivity, MainSparkyActivity::class.java)
                    startActivity(sparky)
                }
                R.id.nav_connect -> {
                    val connect = Intent(this@MainConnectActivity, MainConnectActivity::class.java)
                    startActivity(connect)
                }
            }
            false
        }

    }






}
