package org.intracode.saelenspace

import android.support.v7.app.AppCompatActivity
import android.os.Bundle

class SubjectActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_subject)

        val navBarTitle = intent.getStringExtra(CustomSparkHold.subTitle)
        supportActionBar?.title = navBarTitle



    }
}
